import {onHome} from './home.js';
import {navBar} from './nav.js';


onHome();
navBar();